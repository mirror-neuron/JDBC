package com.test;

public class MemberDTO
{
	private String EMP_NAME, SSN, IBSADATE, TEL, CITY_LOC, BUSEO_NAME, JIKWI_NAME; 
	private int EMP_ID, CITY_ID, BUSEO_ID, JIKWI_ID, MIN_BASICPAY, BASICPAY, SUDANG;
	public String getEMP_NAME()
	{
		return EMP_NAME;
	}
	public void setEMP_NAME(String eMP_NAME)
	{
		EMP_NAME = eMP_NAME;
	}
	public String getSSN()
	{
		return SSN;
	}
	public void setSSN(String sSN)
	{
		SSN = sSN;
	}
	public String getIBSADATE()
	{
		return IBSADATE;
	}
	public void setIBSADATE(String iBSADATE)
	{
		IBSADATE = iBSADATE;
	}
	public String getTEL()
	{
		return TEL;
	}
	public void setTEL(String tEL)
	{
		TEL = tEL;
	}
	public String getCITY_LOC()
	{
		return CITY_LOC;
	}
	public void setCITY_LOC(String cITY_LOC)
	{
		CITY_LOC = cITY_LOC;
	}
	public String getBUSEO_NAME()
	{
		return BUSEO_NAME;
	}
	public void setBUSEO_NAME(String bUSEO_NAME)
	{
		BUSEO_NAME = bUSEO_NAME;
	}
	public String getJIKWI_NAME()
	{
		return JIKWI_NAME;
	}
	public void setJIKWI_NAME(String jIKWI_NAME)
	{
		JIKWI_NAME = jIKWI_NAME;
	}
	public int getEMP_ID()
	{
		return EMP_ID;
	}
	public void setEMP_ID(int eMP_ID)
	{
		EMP_ID = eMP_ID;
	}
	public int getCITY_ID()
	{
		return CITY_ID;
	}
	public void setCITY_ID(int cITY_ID)
	{
		CITY_ID = cITY_ID;
	}
	public int getBUSEO_ID()
	{
		return BUSEO_ID;
	}
	public void setBUSEO_ID(int bUSEO_ID)
	{
		BUSEO_ID = bUSEO_ID;
	}
	public int getJIKWI_ID()
	{
		return JIKWI_ID;
	}
	public void setJIKWI_ID(int jIKWI_ID)
	{
		JIKWI_ID = jIKWI_ID;
	}
	public int getMIN_BASICPAY()
	{
		return MIN_BASICPAY;
	}
	public void setMIN_BASICPAY(int mIN_BASICPAY)
	{
		MIN_BASICPAY = mIN_BASICPAY;
	}
	public int getBASICPAY()
	{
		return BASICPAY;
	}
	public void setBASICPAY(int bASICPAY)
	{
		BASICPAY = bASICPAY;
	}
	public int getSUDANG()
	{
		return SUDANG;
	}
	public void setSUDANG(int sUDANG)
	{
		SUDANG = sUDANG;
	}
	
	
}
